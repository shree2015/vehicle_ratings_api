/* 
 * NHTSAController.js - Controller for handling all NHTSA related calls
 * Author: Ojas Kale
 * Date: 12th May 2018
 * Version: 1
 */

var webRequests = require('../utils/webRequests');
var utils = require('../utils/utils');

const NHTSAApi = 'https://one.nhtsa.gov/webapi/api/SafetyRatings';
const modelParam = 'model';
const makeParam = 'make';
const modelYearParam = 'modelYear';

const validParams = ["modelyear", "make", "model"];

var getVehicleData = function(requestParams, callback) {
    var jsonObject = utils.modifyJsonKeys(requestParams, "manufacturer", "make");
    var queryString = createNHTSAQueryString(jsonObject);
    webRequests.sendRequest(NHTSAApi, queryString, function(err, result) {
        if(err) {
            console.log(" !!! ERROR received from NHTSA request");
        }
        else {
            //var result = {requestType: "Get Request without params from Controller"};
            var jsonResult = JSON.parse(result);
            jsonResult = modifyJson(jsonResult);
            callback(null, jsonResult);
        }        
    });

};

var getVehicleRatingData = function(vehicle, callback) {
    var queryString = '';
    queryString += '/VehicleId/' + vehicle.VehicleId + "?format=json";
    webRequests.sendRequest(NHTSAApi, queryString, function(err, result) {
        if(err) {
            console.log(" !!! ERROR received from NHTSA request");
        }
        else {
            //var result = {requestType: "Get Request without params from Controller"};
            var jsonResult = JSON.parse(result);
            //jsonResult = modifyJson(jsonResult);
            callback(null, jsonResult);
        }        
    });    
}

function modifyJson(jsonObject) {
    var jsonResult = utils.modifyJsonKeys(jsonObject, "Message", null);
    if(jsonResult.Results) {
        var modifiedArray = jsonResult.Results.map(function(result) {
            var newResult = {};
            for(var key in result) {
                if (key === "VehicleDescription") 
                    newResult.Description = result[key];
                else
                    newResult[key] = result[key];
                }
                return newResult;
            });
        jsonResult.Results = modifiedArray;
    }
    
    return jsonResult;
}
    

var createNHTSAQueryString = function(params) {
    var queryString = '';
    for(i = 0; i < validParams.length; i++ ) {
        var currentParam = validParams[i];
        var value = params[currentParam];
        queryString += '/';
        queryString += currentParam.toLowerCase();
        queryString += '/';
        queryString += value;
    }
    return queryString;
};


module.exports.getVehicleData = getVehicleData;
module.exports.getVehicleRatingData = getVehicleRatingData;